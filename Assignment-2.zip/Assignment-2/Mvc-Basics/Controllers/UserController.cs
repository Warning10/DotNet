﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using Mvc_Basics.Models;


namespace Mvc_Basics.Controllers
{
    public class UserController : Controller
    {
        // Hardcoded list of users
        private static readonly List<User> Users = new List<User>
        {
            new User { Id = 1, Name = "Alice Johnson", Email = "alice@example.com", Username = "alicej" },
            new User { Id = 2, Name = "Bob Smith", Email = "bob@example.com", Username = "bobsmith" },
            new User { Id = 3, Name = "Charlie Brown", Email = "charlie@example.com", Username = "charlieb" }
        };

        public IActionResult Index()
        {
            return View(Users);
        }
    }
}
